clc
clear
global dmodelL1
num_vari=8;
%LHS
dist=ones(1,num_vari);
mu=0.5*ones(num_vari,1);
sigma=0*ones(num_vari,1);
lowb=[0.05;100;63070;990;63.1;700;1120;9855];
upb=[0.15;50000;115600;1110;116;820;1680;12045];
%% HF and LF samples
SL=LHS(90,dist,mu,sigma,lowb,upb);%LF
SH=LHS(30,dist,mu,sigma,lowb,upb);%HF
YL=LF_fun(SL);YH=HF_fun(SH);%
SS=LHS(200,dist,mu,sigma,lowb,upb);YY=HF_fun(SS);%VALIDATION SAMPLES
[mm nn]=size(SL);tttt=ones(1,nn);theta=0.1*tttt;lob=(1e-3)*tttt;upb=300*tttt;%Upper and lower bounds of parameters
[dmodelL1,perf1]=dacefit(SL,YL,@regpoly0,@corrgauss,theta,lob,upb); % LF Kriging
%% HK modeling
[HK_dmodel,perf]=dacefith(SH,YH,@regpoly_c,@corrgauss,theta,lob,upb);
%% error metrics
pre4=predictorh(SS,HK_dmodel);
mer4=metrics(YY,pre4)

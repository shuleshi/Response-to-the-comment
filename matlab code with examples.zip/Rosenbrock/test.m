clc
close all
clear all
num_vari=2;
global dmodelL1
%LHS
dist=[1 1];
mu=[0.5;0.5];
sigma=[0;0];
lowb=[-2.048;-2.048];
upb=[2.048;2.048];
%% HF and LF samples
SL=LHS(45,dist,mu,sigma,lowb,upb);%LF
SH=LHS(15,dist,mu,sigma,lowb,upb);%HF
YL=LF_fun(SL);YH=HF_fun(SH);%
SS=LHS(200,dist,mu,sigma,lowb,upb);YY=HF_fun(SS);%VALIDATION SAMPLES
[mm nn]=size(SL);tttt=ones(1,nn);theta=0.1*tttt;lob=(1e-3)*tttt;upb=300*tttt;%Upper and lower bounds of parameters
[dmodelL1,perf1]=dacefit(SL,YL,@regpoly0,@corrgauss,theta,lob,upb);  % LF Kriging
%% HK modeling
[HK_dmodel,perf]=dacefith(SH,YH,@regpoly_c,@corrgauss,theta,lob,upb);
%% error metrics
pre4=predictorh(SS,HK_dmodel);
mer4=metrics(YY,pre4)% figure (1)


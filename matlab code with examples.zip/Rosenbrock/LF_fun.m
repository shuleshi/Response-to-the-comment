function y=LF_fun(x)
y=70*(x(:,1).^2-x(:,2)).^2+0.7*(x(:,1)-1).^2;
end
function y=HF_fun(x)
y=100*(x(:,1).^2-x(:,2)).^2+(x(:,1)-1).^2;
end
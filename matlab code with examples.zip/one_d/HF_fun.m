function y=HF_fun(x)
y=0.5*sin(4*pi*sin(x+0.5))+(x+0.5).^2/3;
end
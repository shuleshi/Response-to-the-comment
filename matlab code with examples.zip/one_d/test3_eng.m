clc
clear all
global dmodelL1
num_vari=1;
lb=0;
ub=1;
%% �临�ӶȽ�ģ����
SL=[0:0.1:1]'; SH=[0:0.27:1]';% HF and LF samples
YL=LF_fun(SL); YH=HF_fun(SH); % HF and LF renponses
[mm nn]=size(SL);
tttt=ones(1,nn);theta=10*tttt;lob=(1e-3)*tttt;upb=300*tttt;%Upper and lower bounds of parameters
[dmodelL1,perf1]=dacefit(SL,YL,@regpoly0,@corrgauss,theta,lob,upb);  % LF Kriging
%% 
XX=[0:0.001:1]';
YY=HF_fun(XX);
YYL=LF_fun(XX);
LF_pre=predictor(XX,dmodelL1);
%% HK model
[HK_dmodel,perf]=dacefith(SH,YH,@regpoly_c,@corrgauss,theta,lob,upb);%
figure (1)
plot(XX,YY,'k-','LineWidth',3)
hold on
pre4=predictorh(XX,HK_dmodel);
hold on
plot(XX,pre4,'b--','LineWidth',3)
l1=legend('HF model','HK model');
set(l1,'Fontname', 'Times New Roman','FontSize',14,'linewidth',2)
set(gca,'XTick',[0:0.2:1],'YTick',[-0.8:0.2:1],'FontSize',14,'linewidth',1.5) 
%error metrics
mer4=metrics(YY,pre4)

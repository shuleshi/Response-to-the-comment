function y=LF_fun(x)
y=0.5*sin(4*pi*sin(1.1*x+0.4))+(1.1*x+0.5).^2/3-0.2;
end
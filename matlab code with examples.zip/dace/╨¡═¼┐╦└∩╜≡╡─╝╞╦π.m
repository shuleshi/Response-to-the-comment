%��������Ϊr1,r2,r12
clear all
clc
load data1
x=[1,2];
syms h
r11=@(h) 0.06+0.7*(1-exp(-h/300));
r22=@(h) 0.22+0.9*(1-exp(-h/100));
r12=@(h) 0.12+0.32*(1.5*(h/100)-0.5*(h/100).^3)-0.7*(1-exp(-h/300))-0.9*(1-exp(-h/100));

X3=S;
X1=S(1:2:end,:);
X2=S(2:2:end,:);
X3=[X1;X2];
m1= size(X1,1);
m2= size(X2,1);
[m3,n]= size(X3);
D = zeros(m3,m3);
for i=1:m3
    D(:,i)=sum((X3- repmat(X3(i,:),m3, 1)).^2,2);
end
% g1=D;
%��ߵľ���
D(1:m1,1:m1) = feval(r11,D(1:m1,1:m1));
D(m1+1:m3,1:m1)=feval(r12,D(m1+1:m3,1:m1));
D(1:m1,m1+1:m3)=feval(r12,D(1:m1,m1+1:m3));
D(m1+1:m3,m1+1:m3)=feval(r22,D(m1+1:m3,m1+1:m3));

ad1=zeros(m3,2);
ad1(1:m1,1)=1;
ad1(m1+1:m3,2)=1;
ad2=zeros(2,m3+2);
ad2(1,1:m1)=1;
ad2(2,m1+1:m3)=1;
D=[D,ad1;ad2];

%�ұߵľ���
H=zeros(m3,1);
H=sum((X3- repmat(x,m3, 1)).^2,2);
g1=H;
H(1:m1)=feval(r12,H(1:m1,1));
H(m1+1:m3)=feval(r22,H(m1+1:m3));
H=[H;0;1];
namta=inv(D)*H;

%����ֵ
guz=sum(Y.*namta(1:end-2));

%����
g2=[feval(r12,g1(1:m1,1));feval(r22,g1(m1+1:m3,1))];
Ys=sum(g2.*namta(1:end-2))+namta(end);
